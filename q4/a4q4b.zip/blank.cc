#include "blank.h"
#include <iostream>

char Blank::charAt(int row, int col, int tick) { return ' '; }

