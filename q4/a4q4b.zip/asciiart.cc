#include "asciiart.h"
#include <iostream>

AsciiArt::~AsciiArt() {}
