# CS246-A5-Chess
Group Members: Aviral (a589shar), Prem (p352pate)
