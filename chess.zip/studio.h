#ifndef BOARD_H
#define BOARD_H
#include <iostream>
#include <vector>

class Cell {
  int row;
  int col;
}

class Board : public Subject {
  
};

#endif
